package com.decorator;

public interface Notifier {
	public void send(String msg);
}
