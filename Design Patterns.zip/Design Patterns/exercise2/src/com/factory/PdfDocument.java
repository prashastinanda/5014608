package com.factory;

public class PdfDocument extends Document {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Opening PDF document...");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Closing PDF document...");
	}

}
