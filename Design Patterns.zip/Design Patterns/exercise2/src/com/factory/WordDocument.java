package com.factory;

public class WordDocument extends Document {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		System.out.println("Opening Word document...");
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println("Closing Word document...");
	}

}
