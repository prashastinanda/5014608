package com.command;

public class Light {

	void turnOn() {

		System.out.println("Switch is turned on");
	}

	void turnOff() {

		System.out.println("Switch is turned off");
	}
}
