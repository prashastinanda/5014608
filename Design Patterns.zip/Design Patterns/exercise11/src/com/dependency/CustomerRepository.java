package com.dependency;

public interface CustomerRepository {

	Customer findCustomerById(String id);
}
