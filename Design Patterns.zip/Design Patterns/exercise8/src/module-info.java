/**
 * 
 */
/**
 * 
 */
module StrategyPatternExample {
}