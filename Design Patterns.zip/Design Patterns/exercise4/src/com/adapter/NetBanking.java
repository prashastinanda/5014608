package com.adapter;

public class NetBanking {

	public void pay(int amount) {

		System.out.println("Amount of Rs." + amount + " made by Net Banking.");
	}
}
