package com.strategy;

public interface PaymentStrategy {

	public abstract void pay(int amount);
}
