package com.command;

public interface Command {

	public abstract void execute();
}
