package com.proxy;

public interface Image {
	public abstract void display();
}
