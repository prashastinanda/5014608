package com.adapter;

public class DebitCard {

	public void pay(int amount) {

		System.out.println("Amount of Rs." + amount + " made by Debit Card.");
	}

}
