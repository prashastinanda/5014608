package com.mvc;

public class StudentView {

	// private String name;
	// private int id;
	// private String grade;

	public void displayStudentDetails(String name, int id, String grade) {

		System.out.println("Student name is: " + name + " Student id is: " + id + " Student grade is: " + grade);
	}
}
